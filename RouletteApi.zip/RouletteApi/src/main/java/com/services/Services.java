package com.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import com.dao.IDBOperations;
import com.model.Bet;
import com.model.Roulette;
import com.model.Winner;
import com.utils.Exceptions;
import static com.utils.Constants.*;

public class Services implements IServices, IDBOperations{

	
	@Override
	public long createRoulette() {
		String sql = "INSERT INTO roulette (status_) VALUES ('"+CREATED_ROULETTE+"');";
		
		return insertRecord(sql);
	}

	
	@Override
	public boolean openRoulette(long id) throws Exceptions{
		boolean response = false;
		String update = "UPDATE roulette set status_ = '"+OPEN_ROULETTE+"' WHERE id ="+id;
		try {
				if(valRouletteById(id, CREATED_ROULETTE)) 
				{
					if(!updateRecord(update)) throw new Exceptions(NON_UPDATED_RECORD); 
					else response = true;
				}
				else response = false;				
		}finally {}
		
		return response;
	}

	
	
	@Override
	public long betRoulette(Bet bet) throws Exceptions{
		String sql;
		try {
			if(bet.getNumber() != NULL_INTEGER && bet.getColor() != null) throw new Exceptions(INVALID_BET_PARAMS);
			if(bet.getNumber() != NULL_INTEGER && (bet.getNumber() <ZERO || bet.getNumber() > 36)) throw new Exceptions(INVALID_NUMBER);
			if(bet.getColor() !=null && (!bet.getColor().toLowerCase().equals(RED) && !bet.getColor().toLowerCase().equals(BLACK))) throw new Exceptions(INVALID_COLOR);
			if(bet.getBetMoneyAmount() <=ZERO || bet.getBetMoneyAmount() > MAX_AMOUNT) throw new Exceptions(INVALID_BET_AMOUNT);
			if(bet.getRouletteId() == ZERO) throw new Exceptions(EMPTY_ROULETTE_ID);
			if(bet.getUserId().equals("")) throw new Exceptions(INVALID_USER_ID);
			valRouletteById(bet.getRouletteId(),OPEN_ROULETTE);
			if(bet.getNumber() != NULL_INTEGER)
				sql = "INSERT INTO bet_roulette (bet_amount, bet_number, id_roulette, id_customer) "
					   + "VALUES ("+bet.getBetMoneyAmount()+", "+bet.getNumber()+","+bet.getRouletteId()+", '"+bet.getUserId()+"');";
			else
			    sql = "INSERT INTO bet_roulette (bet_amount, bet_color, id_roulette, id_customer) "
					   + "VALUES ("+bet.getBetMoneyAmount()+", '"+bet.getColor()+"', "+bet.getRouletteId()+", '"+bet.getUserId()+"');";
		}finally {}	
		
		return insertRecord(sql);
	}

	
	@Override
	public List<Winner> executeRoulette(long id) throws Exceptions{
		valRouletteById(id,OPEN_ROULETTE);
		int executeRulettte =  (int) (Math.random()*36 + 1); 
		String color;
		String update = "UPDATE roulette set status_ = '"+CLOSED_ROULETTE+"' WHERE id ="+id;;
		if(executeRulettte%2==ZERO) color = RED;
		else color = BLACK;
		List<Winner> winners = getWinners(id, executeRulettte, color).stream()
				                         .map( winner -> { 
				                        	 if(winner.getNumber() != NULL_INTEGER) winner.setAmountEarn( winner.getAmountEarn()*5.0);
				                        	 else winner.setAmountEarn(winner.getAmountEarn()*1.8);
                							 return winner;
				                         })
                                         .collect(Collectors.toList()); 
		updateRecord(update);
		
		return winners;
	}

	
	public List<Winner> getWinners(long idRoulette, int number, String color)
	{
		List<Winner> winners = new ArrayList<Winner>(); 	
		try(Connection connection = connecToDB()){
			String query = "select id_customer, id, bet_number, bet_color, bet_amount FROM bet_roulette WHERE id_roulette ="+idRoulette+ " "
					     + "AND (bet_number = "+number+" OR bet_color='"+color+"')";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {
				int betNumber =  ((rs.getString("bet_number")) == null) ? NULL_INTEGER : Integer.valueOf(rs.getString("bet_number"));
				Winner win = new Winner(rs.getString("id_customer"), Integer.valueOf(rs.getString("id")), 
						                Integer.valueOf(rs.getString("bet_amount")), betNumber,rs.getString("bet_color"));	
				winners.add(win); 
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return winners;
	}
	
	
	
	@Override
	public List<Roulette> getAllRoulettes() {
		List<Roulette> roulettes = new ArrayList<Roulette>(); 
		String status;
		try(Connection connection = connecToDB()){
			String query = "select id, status_ FROM roulette; ";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()) {				
				if( rs.getString("status_").equals(CREATED_ROULETTE))  status = "Creada";
				else if(rs.getString("status_").equals(OPEN_ROULETTE)) status = "Abierta";
				else status = "Cerrada";
				Roulette roul = new Roulette(Long.valueOf(rs.getString("id")), status);	
				roulettes.add(roul); 
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return roulettes;
	}

	
	
	
	
	@Override
	public long insertRecord(String sql) {
		long id =0;
		try(Connection connection = connecToDB())
		{
			Statement statement = connection.createStatement();
			statement.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS); 
			ResultSet rs = statement.getGeneratedKeys();
			if (rs.next()) id =rs.getInt(1);
	        rs.close();
	        statement.close();
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return id;
	}

	
	
	@Override
	public boolean updateRecord(String sql)
	{
		boolean updated = false;
		try(Connection connection = connecToDB())
		{
			Statement statement = connection.createStatement();
			if(statement.executeUpdate(sql) > 0) updated = true;
			else updated = false;
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return updated;
	}

	
	
	public boolean valRouletteById(long id, String validStatus) throws Exceptions{
		boolean response = false;
		String query = "SELECT id,status_ FROM roulette WHERE id="+id;
		try{
			Roulette roulette =  getRouleteById(query);
			if(roulette != null) 
			{
				if(!roulette.getStatus().equals(validStatus)) throw new Exceptions(INVALID_ROULETTE_ERR);
				else response = true;
			}
			else throw new Exceptions(UNEXIST_ROULETTE_ERR);
		}finally {}
		
		return response;
	}
	
	
	public Roulette getRouleteById(String sql) {
		Roulette record= null;
		try(Connection connection = connecToDB())
		{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = null;		
			rs = preparedStatement.executeQuery();
			if(rs.next()) record = new Roulette(Integer.valueOf(rs.getString("id")), rs.getString("status_"));
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Se ha producido el siguiente error: " + e.getMessage(), e);
		}
		
		return record;
	}


	
}

