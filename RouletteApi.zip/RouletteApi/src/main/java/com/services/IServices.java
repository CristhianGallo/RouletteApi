package com.services;

import java.util.List;

import com.model.Bet;
import com.model.Roulette;
import com.model.Winner;
import com.utils.Exceptions;


public interface IServices {
	
	
	public long createRoulette();
	
	public boolean openRoulette(long id) throws Exceptions;
	
	public long betRoulette(Bet bet) throws Exceptions;
	
	public List<Winner> executeRoulette(long id) throws Exceptions;
	
	public List<Roulette> getAllRoulettes();

}
