package com.model;

public class Winner {

	private String userId;
	private long betId;
	private double amountEarn;
	private int  number;
	private String color;
	

	public Winner() {
		super();
	}



	public Winner(String userId, long betId, double amountEarn, int number, String color) {
		super();
		this.userId = userId;
		this.betId = betId;
		this.amountEarn = amountEarn;
		this.number = number;
		this.color = color;
	}



	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public long getBetId() {
		return betId;
	}


	public void setBetId(long betId) {
		this.betId = betId;
	}



	public double getAmountEarn() {
		return amountEarn;
	}



	public void setAmountEarn(double amountEarn) {
		this.amountEarn = amountEarn;
	}



	public int getNumber() {
		return number;
	}



	public void setNumber(int number) {
		this.number = number;
	}



	public String getColor() {
		return color;
	}



	public void setColor(String color) {
		this.color = color;
	}



	@Override
	public String toString() {
		return "Winner [userId=" + userId + ", betId=" + betId + ", amountEarn=" + amountEarn + ", number=" + number
				+ ", color=" + color + "]";
	}

	
}

