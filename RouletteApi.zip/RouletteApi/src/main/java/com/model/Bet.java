package com.model;

import java.util.Optional;

public class Bet {

	
	private String color;
	private Optional<Integer> number;
	private long rouletteId;
	private String userId;
	private int betMoneyAmount;
	
	public Bet() {
	}




	public Bet(String color, Optional<Integer> number, long roulette_id, String userId, int betMoneyAmount) {
		super();
		this.color = color;
		this.number = number;
		this.rouletteId = roulette_id;
		this.userId = userId;
		this.betMoneyAmount = betMoneyAmount;
	}
	
	
	
	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public int getNumber() {
		int numb;
		try
		{
			if(number.isPresent()) numb = number.get();
			else numb = -100;
		}catch(Exception ex) {
			numb = -100;
		}
		
		return numb;
	}


	public void setNumber(Optional<Integer> number) {
		this.number = number;
	}

	
	public long getRouletteId() {
		return rouletteId;
	}


	public void setRouletteId(long roulette_id) {
		this.rouletteId = roulette_id;
	}



	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}




	public int getBetMoneyAmount() {
		return betMoneyAmount;
	}




	public void setBetMoneyAmount(int betMoneyAmount) {
		this.betMoneyAmount = betMoneyAmount;
	}




	@Override
	public String toString() {
		return "Bet [color=" + color + ", number=" + number + ", rouletteId=" + rouletteId + ", userId=" + userId
				+ ", betMoneyAmount=" + betMoneyAmount + "]";
	}



	

	
	
}
