package com.dao;

import static com.utils.Constants.*;

import java.sql.Connection;
import java.sql.DriverManager;

public interface IDBOperations {

	
		default Connection connecToDB() {
			Connection connection = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				connection = DriverManager.getConnection(URL+DB_NAME, DB_USER, DB_PASSWORD);
			}catch(Exception ex){
				ex.printStackTrace();
				throw new RuntimeException("Se ha producido el siguiente error: " + ex.getMessage(), ex);
			}
			
			return connection;
		}
		
		
		public long insertRecord(String sql);
		
		public boolean updateRecord(String sql);
	
}
