package com.controller;

import javax.validation.Valid;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.model.Bet;
import com.model.Roulette;
import com.model.Winner;
import com.services.*;
import java.util.ArrayList;
import java.util.List;

@RestController
public class RouletteController {
		
	private IServices service = new Services();
	
	
	@GetMapping("/create")
	public ResponseEntity<String> getRoulette() {		
		JSONObject jsonResponse = new JSONObject();
		ResponseEntity response =null;
		try {
			jsonResponse.put("id",service.createRoulette());  
			response = ResponseEntity.ok(jsonResponse.toString());
		}catch(Exception ex)
		{
			response =  ResponseEntity.badRequest().body(ex.toString());
		}
		
		return response;
	}
	

	@PostMapping("/open")
	public ResponseEntity<String> openRoulette(@RequestParam(value="id") long id) {		
		ResponseEntity response =null;
		try {
			if(service.openRoulette(id)) response = ResponseEntity.status(HttpStatus.OK).body("Operación exitosa");
			else response = ResponseEntity.status(HttpStatus.NOT_FOUND).body("Operación falló");
		}catch(Exception ex)
		{
			response =  ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.toString());
		}
		
		return response;
	}
	
	
	
	@PostMapping("/bet")
	public ResponseEntity<String> getRoulette(@Valid @RequestBody Bet bet, @RequestHeader("user_id") String user_id )
	{
		ResponseEntity response =null;
		JSONObject jsonResponse = new JSONObject();
		try {
			bet.setUserId(user_id);
			jsonResponse.put("bet_id",service.betRoulette(bet)); 
			response = ResponseEntity.ok(jsonResponse.toString());
		}catch(Exception ex)
		{
			jsonResponse.put("error",ex.toString());
			response =  ResponseEntity.badRequest().body(jsonResponse.toString());
		}
		
		return response;
	}

	
	
	@PutMapping("/executeRulette")
	public ResponseEntity<List<Winner>> execRulette(@RequestParam(value="id") long id) {		
		ResponseEntity response =null;
		List<Winner> winners;
		try {
			winners = service.executeRoulette(id);
			response = ResponseEntity.ok(winners);
		}catch(Exception ex)
		{
			winners = new ArrayList();
			response =  ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(winners);
		}
		
		return response;
	}
	
	
	
	@GetMapping("/getAllRouletes")
	public ResponseEntity<List<Roulette>> getAllRouletes() {		
		ResponseEntity response =null;
		List<Roulette> roulettes;
		try {
			roulettes = service.getAllRoulettes();
			response = ResponseEntity.ok(roulettes);
		}catch(Exception ex)
		{
			roulettes = new ArrayList();
			response =  ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(roulettes);
		}
		
		return response;
	}
	
	
}
